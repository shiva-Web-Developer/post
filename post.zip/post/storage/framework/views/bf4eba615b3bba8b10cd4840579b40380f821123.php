<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card Design</title>
    <!-- Add Bootstrap 4 CSS CDN -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-6 m-auto">
                <div class="card">
                <?php if(session('success')): ?>
                    <button style="color:green;"><?php echo e(session('success')); ?></button>
                    <?php endif; ?>
                    <?php if(session('error')): ?>
                    <button style="color:red;"><?php echo e(session('error')); ?></button>
                    <?php endif; ?>
                    <div class="card-body">
                        <h5 class="card-title">Name: <?php echo e($data['user']->name); ?></h5>
                        <p class="card-text">Email: <?php echo e($data['user']->email); ?></p>
                        <a href="<?php echo e(route('user.logout')); ?>" onclick="return confirm('Are you sure you want to logout?')">Logout</a><br>
                        <a href="<?php echo e(route('create.post')); ?>">create a post</a>
                    </div>
                </div>
            </div>
        </div><br>
        <div class="row">
            <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3">
                <div class="card">
                    <img src="<?php echo e(url('images/' . $res->image)); ?>" class="card-img-top" alt="User's Profile Picture">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($res->title); ?></h5>
                        <p class="card-text"><?php echo e($res->description); ?></p>
                        <span><?php echo e($res->created_at); ?></span>
                    </div>
                    <div class="card-footer">
                        <div class="card-footer">
                            <a href="<?php echo e(route('edit.post', ['id' => $res->id])); ?>" class="btn btn-primary">Edit</a>
                            <a onclick="return confirm('Are you sure you want to Delete?')" href="<?php echo e(route('post.delete', ['id' => $res->id])); ?>" class="btn btn-danger">Delete</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>
    </div>

</body>

</html><?php /**PATH C:\xampp\htdocs\post\resources\views/post/index.blade.php ENDPATH**/ ?>